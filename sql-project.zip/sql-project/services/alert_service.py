# services/alert_service.py
from datetime import datetime
from typing import Dict, Any, List, Optional
from models import db
from models.alert_model import AlertRule, AlertRecord, AlertNotification
from .base_service import BaseService

class AlertRuleService(BaseService):
    """预警规则服务"""
    def __init__(self):
        super().__init__(AlertRule)

    def get_active_rules(self) -> List[Dict[str, Any]]:
        rules = self.model_class.query.filter_by(IsActive=True).all()
        return [r.to_dict() for r in rules]

class AlertRecordService(BaseService):
    """预警记录服务"""
    def __init__(self):
        super().__init__(AlertRecord)


    def get_alerts_by_area(self, area_id: str) -> List[Dict[str, Any]]:
        alerts = self.model_class.query.filter_by(AreaID=area_id).all()
        return [a.to_dict() for a in alerts]

    def list_all(self):
        return self.model_class.query.order_by(self.model_class.TriggerTime.desc()).all()

    def create_alert(self, data: Dict[str, Any]) -> AlertRecord:
        data['TriggerTime'] = datetime.now()
        return self.create(data)

    def update_status(self, alert_id: str, status: str, handler_id: Optional[str] = None, result: Optional[str] = None) -> bool:
        alert = self.get_by_id(alert_id)
        if alert:
            alert.Status = status
            if handler_id:
                alert.HandlerID = handler_id
            if result:
                alert.Result = result
            alert.UpdateTime = datetime.now()
            db.session.commit()
            return True
        return False

class AlertNotificationService(BaseService):
    """通知记录服务"""
    def __init__(self):
        super().__init__(AlertNotification)

    def get_notifications_by_alert(self, alert_id: str) -> List[Dict[str, Any]]:
        notes = self.model_class.query.filter_by(AlertID=alert_id).all()
        return [n.to_dict() for n in notes]

    def create_notification(self, data: Dict[str, Any]) -> AlertNotification:
        data['SendTime'] = datetime.now()
        return self.create(data)

    def update_receive_status(self, notification_id: str, status: str) -> bool:
        note = self.get_by_id(notification_id)
        if note:
            note.ReceiveStatus = status
            db.session.commit()
            return True
        return False
