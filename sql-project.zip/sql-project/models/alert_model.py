# models/alert_model.py
from models.base_model import db, BaseModel
from datetime import datetime

class AlertRule(BaseModel):
    """预警规则模型"""
    __tablename__ = 'AlertRule'

    RuleID = db.Column(db.String(32), primary_key=True, comment='规则编号')
    AlertType = db.Column(db.String(16), nullable=False, comment='预警类型')
    Condition = db.Column(db.String(128), nullable=False, comment='触发条件')
    Level = db.Column(db.String(8), nullable=False, comment='预警级别')
    IsActive = db.Column(db.Boolean, default=True, comment='生效状态')
    CreateTime = db.Column(db.DateTime, default=datetime.now, comment='创建时间')
    UpdateTime = db.Column(db.DateTime, default=datetime.now, onupdate=datetime.now, comment='更新时间')

    alerts = db.relationship('AlertRecord', backref='rule', lazy=True)

    def __repr__(self):
        return f'<AlertRule {self.RuleID} {self.AlertType}>'

class AlertRecord(BaseModel):
    def to_dict(self):
        # 课设要求的所有字段
        rule = self.rule if hasattr(self, 'rule') else None
        return {
            'AlertID': self.AlertID,
            'RuleID': self.RuleID,
            'AlertType': rule.AlertType if rule else None,
            'Condition': rule.Condition if rule else None,
            'Level': rule.Level if rule else None,
            'AreaID': self.AreaID,
            'TriggerTime': self.TriggerTime.strftime('%Y-%m-%d %H:%M:%S') if self.TriggerTime else None,
            'Content': self.Content,
            'Status': self.Status,
            'HandlerID': self.HandlerID,
            'Result': self.Result
        }
    """预警记录模型"""
    __tablename__ = 'AlertRecord'

    AlertID = db.Column(db.String(32), primary_key=True, comment='预警编号')
    RuleID = db.Column(db.String(32), db.ForeignKey('AlertRule.RuleID', ondelete='RESTRICT', onupdate='CASCADE'), nullable=False, comment='触发规则编号')
    AreaID = db.Column(db.String(15), db.ForeignKey('Area.AreaID', ondelete='RESTRICT', onupdate='CASCADE'), nullable=False, comment='涉及区域编号')
    TriggerTime = db.Column(db.DateTime, nullable=False, default=datetime.now, comment='触发时间')
    Content = db.Column(db.String(256), nullable=False, comment='预警内容')
    Status = db.Column(db.String(8), nullable=False, default='未处理', comment='处理状态')
    HandlerID = db.Column(db.String(15), db.ForeignKey('User.UserID', ondelete='RESTRICT', onupdate='CASCADE'), comment='处理人ID')
    Result = db.Column(db.String(128), comment='处理结果')

    notifications = db.relationship('AlertNotification', backref='alert', lazy=True)

    def __repr__(self):
        return f'<AlertRecord {self.AlertID}>'

class AlertNotification(BaseModel):
    """通知记录模型"""
    __tablename__ = 'AlertNotification'

    NotificationID = db.Column(db.String(32), primary_key=True, comment='通知编号')
    AlertID = db.Column(db.String(32), db.ForeignKey('AlertRecord.AlertID', ondelete='RESTRICT', onupdate='CASCADE'), nullable=False, comment='预警编号')
    ReceiverID = db.Column(db.String(15), db.ForeignKey('User.UserID', ondelete='RESTRICT', onupdate='CASCADE'), nullable=False, comment='接收人ID')
    Method = db.Column(db.String(16), nullable=False, comment='通知方式')
    SendTime = db.Column(db.DateTime, nullable=False, default=datetime.now, comment='发送时间')
    ReceiveStatus = db.Column(db.String(8), nullable=False, default='未接收', comment='接收状态')

    def __repr__(self):
        return f'<AlertNotification {self.NotificationID}>'
