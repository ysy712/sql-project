# api/alert.py
"""
灾害预警API模块
"""
from flask import jsonify, request
from . import alert_bp
from services.alert_service import AlertRuleService, AlertRecordService, AlertNotificationService

rule_service = AlertRuleService()
record_service = AlertRecordService()
notification_service = AlertNotificationService()


@alert_bp.route('', methods=['GET'])
def get_alerts():
    """获取所有预警记录"""
    alerts = record_service.list_all()
    return jsonify({'code': 200, 'message': '预警列表', 'data': [a.to_dict() for a in alerts]})


@alert_bp.route('/rules', methods=['GET'])
def get_rules():
    """获取所有预警规则"""
    rules = rule_service.list_all()
    return jsonify({'code': 200, 'message': '预警规则列表', 'data': [r.to_dict() for r in rules]})


@alert_bp.route('/<alert_id>', methods=['GET'])
def get_alert_detail(alert_id):
    """获取预警详情"""
    alert = record_service.get_by_id(alert_id)
    if alert:
        return jsonify({'code': 200, 'message': '预警详情', 'data': alert.to_dict()})
    else:
        return jsonify({'code': 404, 'message': '预警不存在', 'data': None})


@alert_bp.route('/<alert_id>/notifications', methods=['GET'])
def get_alert_notifications(alert_id):
    """获取预警通知记录"""
    notes = notification_service.get_notifications_by_alert(alert_id)
    return jsonify({'code': 200, 'message': '通知记录', 'data': notes})


@alert_bp.route('/rules', methods=['POST'])
def create_rule():
    """新增预警规则"""
    data = request.json
    rule = rule_service.create(data)
    return jsonify({'code': 201, 'message': '规则创建成功', 'data': rule.to_dict()})


@alert_bp.route('', methods=['POST'])
def create_alert():
    """新增预警记录"""
    data = request.json
    alert = record_service.create_alert(data)
    return jsonify({'code': 201, 'message': '预警创建成功', 'data': alert.to_dict()})


@alert_bp.route('/<alert_id>/status', methods=['PUT'])
def update_alert_status(alert_id):
    """更新预警处理状态"""
    data = request.json
    status = data.get('status')
    handler_id = data.get('handler_id')
    result = data.get('result')
    success = record_service.update_status(alert_id, status, handler_id, result)
    return jsonify({'code': 200 if success else 404, 'message': '状态更新' if success else '预警不存在'})


@alert_bp.route('/<alert_id>/notify', methods=['POST'])
def create_notification(alert_id):
    """新增通知记录"""
    data = request.json
    data['AlertID'] = alert_id
    note = notification_service.create_notification(data)
    return jsonify({'code': 201, 'message': '通知创建成功', 'data': note.to_dict()})


@alert_bp.route('/notifications/<notification_id>/status', methods=['PUT'])
def update_notification_status(notification_id):
    """更新通知接收状态"""
    data = request.json
    status = data.get('status')
    success = notification_service.update_receive_status(notification_id, status)
    return jsonify({'code': 200 if success else 404, 'message': '接收状态更新' if success else '通知不存在'})