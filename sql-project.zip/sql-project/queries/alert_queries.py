# queries/alert_queries.py
from models import db
from models.alert_model import AlertRule, AlertRecord, AlertNotification
from sqlalchemy import and_, or_

def get_recent_alerts(area_id: str, days: int = 7):
    """查询某区域近days天预警及处理情况"""
    from datetime import datetime, timedelta
    since = datetime.now() - timedelta(days=days)
    return AlertRecord.query.filter(
        and_(AlertRecord.AreaID == area_id, AlertRecord.TriggerTime >= since)
    ).order_by(AlertRecord.TriggerTime.desc()).all()

def get_alerts_by_status(status: str):
    """按处理状态查询预警"""
    return AlertRecord.query.filter_by(Status=status).all()

def get_notifications_by_receiver(receiver_id: str):
    """查询某用户收到的所有通知"""
    return AlertNotification.query.filter_by(ReceiverID=receiver_id).all()

def get_active_rules_by_type(alert_type: str):
    """查询某类型启用的预警规则"""
    return AlertRule.query.filter(and_(AlertRule.AlertType == alert_type, AlertRule.IsActive == True)).all()
