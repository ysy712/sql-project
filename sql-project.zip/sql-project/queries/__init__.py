# queries/__init__.py
from .resource_queries import *
from .alert_queries import *
