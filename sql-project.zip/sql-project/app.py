# app.py
from flask import Flask, jsonify, request, session
from flask_cors import CORS
from config import Config
from models import db
from services.alert_service import AlertRecordService

# 实例化服务
alert_service = AlertRecordService()

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    
    # 设置密钥，用于加密 session
    app.secret_key = 'your_secret_key_123456' 

    # 1. 初始化数据库
    db.init_app(app)

    # 2. 启用CORS
    CORS(app)

    # ================= 页面路由 =================
    @app.route('/')
    def index():
        return jsonify({'status': '系统运行中', 'db': '已连接'})

    @app.route('/health')
    def health():
        return jsonify({'status': 'healthy'})

    @app.route('/about')
    def about():
        return jsonify({'info': '数据库课程设计项目'})

    # ================= API 接口 =================

    # 接口1：获取预警列表
    @app.route('/api/alerts', methods=['GET'])
    def get_alert_list():
        try:
            alerts = alert_service.list_all()
            data = [alert.to_dict() for alert in alerts]
            return jsonify({'code': 200, 'msg': 'success', 'data': data})
        except Exception as e:
            print(f"查询失败: {e}")
            return jsonify({'code': 500, 'msg': str(e)}), 500

    # 接口2：模拟登录
    @app.route('/api/auth/login', methods=['POST'])
    def login():
        data = request.json
        username = data.get('username')
        # 简单模拟登录，将用户存入session
        session['user_id'] = 'USR-SYS-002' 
        session['username'] = username
        return jsonify({'code': 200, 'msg': '登录成功'})

    # 接口3：处理预警
    @app.route('/api/alerts/process', methods=['POST'])
    def process_alert():
        try:
            data = request.json
            alert_id = data.get('alert_id')
            method = data.get('method')
            content = data.get('content')
            
            # ========================================================
            # 【核心修复点】这里必须加引号！！！
            # 你的旧代码是 handler_id = USR-SYS-002 (这是错的)
            # 正确代码是 handler_id = 'USR-SYS-002' (这是对的)
            # ========================================================
            handler_id = 'USR-SYS-002' 
            
            result_text = f"【{method}】{content}"
            
            success = alert_service.update_status(
                alert_id=alert_id, 
                status='已处理', 
                handler_id=handler_id, 
                result=result_text 
            )
            
            if success:
                return jsonify({'code': 200, 'msg': '处理成功'})
            else:
                return jsonify({'code': 404, 'msg': '未找到该预警ID'}), 404
                
        except Exception as e:
            print(f"❌ 处理预警失败: {e}")
            # 这里会把真实的Python报错返回给前端
            return jsonify({'code': 500, 'msg': str(e)}), 500

    return app

if __name__ == '__main__':
    app = create_app()
    print("🌲 智慧林草系统后端已启动...")
    print("👉 接口地址: http://localhost:5000/api/alerts")
    app.run(debug=True, host='0.0.0.0', port=5000)