# main.py - 主应用入口文件
from flask import Flask, jsonify, render_template, request, redirect, url_for, session
from flask_cors import CORS
from sqlalchemy import text  # 【必须】引入 text 用于执行原生 SQL
from config import Config
from models import db
from api import init_api
from services.alert_service import AlertRecordService
import os
from datetime import datetime

# 实例化预警服务
alert_service = AlertRecordService()

def create_app():
    """创建Flask应用"""
    app = Flask(__name__,
                static_folder='static',
                template_folder='templates')

    # 加载配置
    app.config.from_object(Config)
    Config.init_app(app)
    
    # 【新增】设置 Session 密钥 (必须有这个才能使用 session 功能)
    app.secret_key = 'your_secret_key_123456'

    # 初始化数据库
    db.init_app(app)

    # 启用 CORS (允许前端跨域请求)
    CORS(app)

    # 初始化API
    init_api(app)

    # 创建必要的目录
    os.makedirs('static/uploads', exist_ok=True)
    os.makedirs('templates', exist_ok=True)

    # ================= 页面路由 (保持原样) =================
    # 登录页面
    @app.route('/')
    def index():
        return render_template('login.html')

    # 首页
    @app.route('/home')
    def home():
        return render_template('index.html')

    # 仪表板
    @app.route('/dashboard')
    def dashboard():
        return render_template('monitoring_system.html')

    # 区域管理
    @app.route('/areas')
    def areas():
        return render_template('monitoring_system.html')

    # 环境监测系统
    @app.route('/monitoring')
    def monitoring():
        return render_template('monitoring_system.html')

    # 传感器管理（重定向到监测系统）
    @app.route('/sensors')
    def sensors():
        return redirect('/monitoring')

    # 监测数据（重定向到监测系统）
    @app.route('/monitors')
    def monitors():
        return redirect('/monitoring')

    # 用户管理
    @app.route('/user-management')
    def user_management():
        return render_template('user_management.html')

    # 灾害预警
    @app.route('/disaster-warning')
    def disaster_warning():
        return render_template('disaster_warning.html')

    # 资源管理
    @app.route('/resource-management')
    def resource_management():
        return render_template('resource_management.html')

    # 设备管理
    @app.route('/device-management')
    def device_management():
        return render_template('device_management.html')

    # 统计分析
    @app.route('/statistical-analysis')
    def statistical_analysis():
        return render_template('statistical_analysis.html')

    # ================= 预警业务接口 (修复并增强版) =================

    # 1. 获取用户列表 (新增接口：供前端下拉框使用)
    @app.route('/api/users', methods=['GET'])
    def get_users():
        try:
            # 使用原生SQL查询 User 表的 ID 和 Username
            sql = text("SELECT UserID, Username FROM User")
            result = db.session.execute(sql).fetchall()
            
            # 组装数据
            users = [{'UserID': row[0], 'Username': row[1]} for row in result]
            return jsonify({'code': 200, 'msg': 'success', 'data': users})
        except Exception as e:
            print(f"获取用户失败: {e}")
            return jsonify({'code': 500, 'msg': str(e)}), 500

    # 2. 获取预警列表 (对应前端 loadAlertList)
    @app.route('/api/alerts', methods=['GET'])
    def get_alert_list():
        try:
            # 调用 Service 层获取按时间倒序排列的所有数据
            alerts = alert_service.list_all()
            # 将 SQLAlchemy 对象转换为字典列表 (to_dict 定义在 Model 中)
            data = [alert.to_dict() for alert in alerts]
            return jsonify({'code': 200, 'msg': 'success', 'data': data})
        except Exception as e:
            print(f"Error getting alerts: {e}")
            return jsonify({'code': 500, 'msg': str(e)}), 500

    # 3. 处理预警 (对应前端 confirmProcess)
    # 使用 commit_process 避免与可能的旧路由冲突
    @app.route('/api/alerts/commit_process', methods=['POST'])
    def process_alert():
        try:
            # 获取前端发送的 JSON 数据
            data = request.json
            alert_id = data.get('alert_id')
            method = data.get('method')   # 处置措施
            content = data.get('content') # 处理备注
            
            # 【关键】这里使用真实存在的用户 ID (根据你提供的 ID 列表)
            handler_id = 'USR-SYS-002' 
            
            # 拼接处理结果字符串
            result_text = f"【{method}】{content}"
            
            # 调用 Service 更新状态
            success = alert_service.update_status(
                alert_id=alert_id, 
                status='已处理', 
                handler_id=handler_id, 
                result=result_text
            )
            
            if success:
                return jsonify({'code': 200, 'msg': '处理成功'})
            else:
                return jsonify({'code': 404, 'msg': '未找到该预警记录或更新失败'}), 404
                
        except Exception as e:
            print(f"❌ 处理预警失败: {e}")
            return jsonify({'code': 500, 'msg': str(e)}), 500

    # 4. 创建手动预警 (修复了表名和列名错误)
    @app.route('/api/alerts/create', methods=['POST'])
    def create_alert():
        try:
            data = request.json
            alert_type = data.get('AlertType', '其他')
            
            # 1. 查找规则ID (修正表名为 AlertRule)
            sql = text("SELECT RuleID FROM AlertRule WHERE AlertType LIKE :t LIMIT 1")
            result = db.session.execute(sql, {'t': f'%{alert_type}%'}).fetchone()
            
            # 兜底逻辑：找不到对应规则就取第一条
            if not result:
                result = db.session.execute(text("SELECT RuleID FROM AlertRule LIMIT 1")).fetchone()
            
            if not result:
                return jsonify({'code': 500, 'msg': '数据库 AlertRule 表为空，无法创建预警！'}), 500
                
            valid_rule_id = result[0]
            
            # 2. 插入记录 (修正列名: Content, Status)
            # 注意：移除了 HandleStatus 和 CreatedTime 以避免列名错误
            insert_sql = text("""
                INSERT INTO AlertRecord (AlertID, RuleID, AreaID, Content, TriggerTime, Status)
                VALUES (:aid, :rid, :area, :content, :time, '未处理')
            """)
            
            new_id = f"ALERT-{datetime.now().strftime('%Y%m%d')}-{datetime.now().strftime('%H%M%S')}"
            
            db.session.execute(insert_sql, {
                'aid': new_id,
                'rid': valid_rule_id,
                'area': data.get('AreaID'),
                'content': data.get('Content'),
                'time': datetime.now()
            })
            db.session.commit()
            
            return jsonify({'code': 200, 'msg': '预警发布成功'})
            
        except Exception as e:
            db.session.rollback()
            print(f"❌ 发布预警失败: {e}")
            return jsonify({'code': 500, 'msg': f"数据库错误: {str(e)}"}), 500

    # ================= 系统基础接口 =================

    # 健康检查
    @app.route('/health')
    def health():
        try:
            with app.app_context():
                db.session.execute('SELECT 1')
            db_status = 'connected'
        except:
            db_status = 'disconnected'

        return jsonify({
            'status': 'healthy',
            'database': db_status,
            'timestamp': datetime.now().isoformat(),
            'version': '1.0.0'
        })

    # 测试页面
    @app.route('/test')
    def test_page():
        return '''
        <!DOCTYPE html>
        <html>
        <head>
            <title>API测试</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
        </head>
        <body>
            <div class="container mt-5">
                <h1>API测试页面</h1>
                <div class="list-group mt-4">
                    <a href="/api/environment/areas" class="list-group-item list-group-item-action" target="_blank">区域API测试</a>
                    <a href="/api/environment/sensors" class="list-group-item list-group-item-action" target="_blank">传感器API测试</a>
                    <a href="/api/alerts" class="list-group-item list-group-item-action" target="_blank">预警数据API测试</a>
                    <a href="/health" class="list-group-item list-group-item-action" target="_blank">健康检查</a>
                </div>
            </div>
        </body>
        </html>
        '''

    # API文档页面
    @app.route('/api-docs')
    def api_docs():
        return render_template('api_docs.html') if os.path.exists('templates/api_docs.html') else "API文档页面未找到"

    # 错误处理
    @app.errorhandler(404)
    def not_found(error):
        if request.path.startswith('/api/'):
            return jsonify({
                'code': 404,
                'message': f'API端点 {request.path} 不存在',
                'data': None
            }), 404
        return render_template('404.html'), 404

    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({
            'code': 500,
            'message': '服务器内部错误',
            'data': str(error) if app.debug else None
        }), 500

    return app


if __name__ == '__main__':
    app = create_app()

    print("=" * 60)
    print("🌲 智慧林草环境监测系统")
    print("=" * 60)
    # print(f"数据库: {app.config['SQLALCHEMY_DATABASE_URI']}")
    print("\n🚀 系统已启动!")
    print("\n📱 访问地址:")
    print("• 登录页面: http://localhost:5000")
    print("• 灾害预警: http://localhost:5000/disaster-warning")
    print("\n🔗 API端点:")
    print("• 预警列表: GET /api/alerts")
    print("• 处理预警: POST /api/alerts/commit_process")
    print("• 发布预警: POST /api/alerts/create")
    print("=" * 60)

    app.run(debug=True, host='0.0.0.0', port=5000)